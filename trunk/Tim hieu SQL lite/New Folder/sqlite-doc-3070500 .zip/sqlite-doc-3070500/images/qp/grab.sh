xwd >grab.xwd
convert grab.xwd grab.gif
rm grab.xwd
xv grab.gif
rm grab.gif
